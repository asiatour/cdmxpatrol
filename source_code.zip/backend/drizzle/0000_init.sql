CREATE TABLE `questions` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`district_id` integer NOT NULL,
	`question_id` text NOT NULL,
	`question_text` text NOT NULL,
	`option_0` text NOT NULL,
	`option_1` text NOT NULL,
	`option_2` text NOT NULL,
	`option_3` text NOT NULL,
	`correct_answer` integer NOT NULL,
	`difficulty` text NOT NULL,
	`category` text NOT NULL,
	`created_by` text,
	`created_at` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `questions_question_id_unique` ON `questions` (`question_id`);--> statement-breakpoint
CREATE TABLE `rooms` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`code` text NOT NULL,
	`host_player_id` text,
	`game_state` text DEFAULT '{}' NOT NULL,
	`status` text DEFAULT 'waiting' NOT NULL,
	`created_at` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `rooms_code_unique` ON `rooms` (`code`);