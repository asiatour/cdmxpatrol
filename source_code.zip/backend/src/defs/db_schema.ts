import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";

export const questions = sqliteTable("questions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  districtId: integer("district_id").notNull(),
  questionId: text("question_id").notNull().unique(),
  questionText: text("question_text").notNull(),
  option0: text("option_0").notNull(),
  option1: text("option_1").notNull(),
  option2: text("option_2").notNull(),
  option3: text("option_3").notNull(),
  correctAnswer: integer("correct_answer").notNull(),
  difficulty: text("difficulty").notNull(),
  category: text("category").notNull(),
  createdBy: text("created_by"),
  createdAt: integer("created_at").notNull().default(0),
});

export const questionOverrides = sqliteTable("question_overrides", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  questionId: text("question_id").notNull().unique(),
  districtId: integer("district_id").notNull(),
  questionText: text("question_text").notNull(),
  option0: text("option_0").notNull(),
  option1: text("option_1").notNull(),
  option2: text("option_2").notNull(),
  option3: text("option_3").notNull(),
  correctAnswer: integer("correct_answer").notNull(),
  difficulty: text("difficulty").notNull(),
  category: text("category").notNull(),
  createdAt: integer("created_at").notNull().default(0),
});

export const questionDeletions = sqliteTable("question_deletions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  questionId: text("question_id").notNull().unique(),
  createdAt: integer("created_at").notNull().default(0),
});

export const deletedCustomQuestions = sqliteTable("deleted_custom_questions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  questionId: text("question_id").notNull().unique(),
  districtId: integer("district_id").notNull(),
  questionText: text("question_text").notNull(),
  option0: text("option_0").notNull(),
  option1: text("option_1").notNull(),
  option2: text("option_2").notNull(),
  option3: text("option_3").notNull(),
  correctAnswer: integer("correct_answer").notNull(),
  difficulty: text("difficulty").notNull(),
  category: text("category").notNull(),
  deletedAt: integer("deleted_at").notNull().default(0),
});

export const rooms = sqliteTable("rooms", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  code: text("code").notNull().unique(),
  hostPlayerId: text("host_player_id"),
  gameState: text("game_state").notNull().default("{}"),
  status: text("status").notNull().default("waiting"),
  createdAt: integer("created_at").notNull().default(0),
});
