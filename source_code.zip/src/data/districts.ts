// 16 Alcaldías (Districts) of Mexico City — sequential patrol route
export interface TriviaQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  difficulty: 'easy' | 'medium' | 'hard';
  category: 'geography' | 'landmarks' | 'crimes' | 'english' | 'misc';
}

export type LevelName = 'start' | 'tourist' | 'city' | 'emergency' | 'victory';

export interface Level {
  name: LevelName;
  label: string;
  color: string;
  bgColor: string;
}

export const levels: Record<LevelName, Level> = {
  start: { name: 'start', label: 'Level 0: Start', color: '#FFFFFF', bgColor: '#F8FAFC' },
  tourist: { name: 'tourist', label: 'Level 1: Tourist English', color: '#3B82F6', bgColor: '#EFF6FF' },
  city: { name: 'city', label: 'Level 2: City Interaction', color: '#22C55E', bgColor: '#F0FDF4' },
  emergency: { name: 'emergency', label: 'Level 3: Emergency English', color: '#EAB308', bgColor: '#FEFCE8' },
  victory: { name: 'victory', label: 'Level 4: Final / Victory', color: '#EF4444', bgColor: '#FEF2F2' },
};

export interface District {
  id: number;
  name: string;
  subtitle: string;
  level: LevelName;
  color: string;
  icon: string;
  description: string;
  funFact: string;
  trivia: TriviaQuestion[];
  // Map position as percentage (for absolute positioning on map)
  mapX: number;
  mapY: number;
}

// Sequential patrol route order
export const patrolRoute = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16];

// Which transitions use special transport
export const specialTransitions: Record<number, { type: 'metro' | 'swat'; from: number; to: number }> = {};

export const districts: District[] = [
  // ─── Step 1: Start ─────────────────────────────────────────────
  {
    id: 1, name: "Cuauhtémoc", subtitle: "Centro Histórico", level: 'start',
    color: '#FFFFFF', icon: '🏛️',
    description: "The historic heart of Mexico City, home to the Zócalo, the National Palace, and the Metropolitan Cathedral.",
    funFact: "The name Cuauhtémoc means 'descending eagle' in Nahuatl, honoring the last Aztec emperor.",
    mapX: 50, mapY: 32,
    trivia: [
      // ─── Easy ────────────────────────────────────────────────────
      { id: "c1-e-g", question: "The Zócalo, the massive main square in Cuauhtémoc, is one of the largest public squares in which continent?", options: ["Asia", "Europe", "North America", "South America"], correctAnswer: 2, difficulty: 'easy', category: 'geography' },
      { id: "c1-e-l", question: "What is the name of the historic square in the center of Cuauhtémoc?", options: ["Plaza Garibaldi", "Zócalo", "Plaza Santa Lucía", "Plaza Mayor"], correctAnswer: 1, difficulty: 'easy', category: 'landmarks' },
      { id: "c1-e-c", question: "Pickpocketing is a common petty crime tourists should watch for in crowded areas of Cuauhtémoc, especially around which famous square?", options: ["Plaza Garibaldi", "Zócalo", "Parque México", "Bosque de Chapultepec"], correctAnswer: 1, difficulty: 'easy', category: 'crimes' },
      { id: "c1-e-en", question: "How do you say 'thank you' in English?", options: ["Please", "Thank you", "Excuse me", "Good morning"], correctAnswer: 1, difficulty: 'easy', category: 'english' },
      { id: "c1-e-m", question: "The National Palace, located on the Zócalo, serves as the seat of which branch of government?", options: ["The Senate", "The Federal Executive (President)", "The Supreme Court", "The Military Command"], correctAnswer: 1, difficulty: 'easy', category: 'misc' },
      // ─── Medium ──────────────────────────────────────────────────
      { id: "c1-m-g", question: "Cuauhtémoc is one of the 16 boroughs of Mexico City. Which zone of the city is it located in?", options: ["Poniente (West)", "Sur (South)", "Centro (Center)", "Oriente (East)"], correctAnswer: 2, difficulty: 'medium', category: 'geography' },
      { id: "c1-m-l", question: "The Palacio de Bellas Artes in Cuauhtémoc is an iconic cultural center. What architectural style blends its exterior and interior designs?", options: ["Art Nouveau and Art Deco", "Baroque and Rococo", "Gothic and Romanesque", "Neoclassical and Colonial"], correctAnswer: 0, difficulty: 'medium', category: 'landmarks' },
      { id: "c1-m-c", question: "What type of robbery that targets tourists on Mexico City's Metro lines passing through Cuauhtémoc involves someone distracting you while an accomplice steals your belongings?", options: ["Armed robbery", "Bait-and-switch", "Distraction theft", "Carjacking"], correctAnswer: 2, difficulty: 'medium', category: 'crimes' },
      { id: "c1-m-en", question: "Which sentence correctly uses the past simple tense?", options: ["I have visited the museum yesterday.", "I visited the museum yesterday.", "I am visiting the museum yesterday.", "I was visit the museum yesterday."], correctAnswer: 1, difficulty: 'medium', category: 'english' },
      { id: "c1-m-m", question: "The Cathedral Metropolitana in Cuauhtémoc took approximately how many years to complete?", options: ["About 50 years", "About 100 years", "About 250 years", "About 400 years"], correctAnswer: 2, difficulty: 'medium', category: 'misc' },
      // ─── Hard ────────────────────────────────────────────────────
      { id: "c1-h-g", question: "The Templo Mayor ruins are in Cuauhtémoc. In which decade were they accidentally discovered during electrical work?", options: ["1960s", "1970s", "1980s", "1990s"], correctAnswer: 1, difficulty: 'hard', category: 'geography' },
      { id: "c1-h-l", question: "The Torre Latinoamericana, a Cuauhtémoc landmark, was the tallest building in Latin America from 1950 until which year?", options: ["1975", "1982", "1985", "1990"], correctAnswer: 1, difficulty: 'hard', category: 'landmarks' },
      { id: "c1-h-c", question: "Which type of violent crime has historically been a concern for businesses in the Tepito neighborhood within Cuauhtémoc?", options: ["Arson", "Organized retail crime and extortion", "Cybercrime", "Wildlife trafficking"], correctAnswer: 1, difficulty: 'hard', category: 'crimes' },
      { id: "c1-h-en", question: "What does the English idiom 'to steal someone's thunder' mean?", options: ["To steal someone's property", "To take credit for someone else's achievement", "To make a loud noise", "To move very quickly"], correctAnswer: 1, difficulty: 'hard', category: 'english' },
      { id: "c1-h-m", question: "The Hemiciclo a Juárez on the Zócalo was installed to honor President Benito Juárez. In what year was it erected?", options: ["1870", "1910", "1921", "1952"], correctAnswer: 1, difficulty: 'hard', category: 'misc' },
    ]
  },
  // ─── Step 2: Poniente (Blue) ───────────────────────────────────
  {
    id: 2, name: "Azcapotzalco", subtitle: "", level: 'tourist',
    color: '#3B82F6', icon: '🏆',
    description: "A northern industrial district with a rich pre-Hispanic heritage, once the capital of the Tepanec Empire.",
    funFact: "Azcapotzalco was the capital of the powerful Tepanec Empire before the Aztecs conquered it.",
    mapX: 38, mapY: 18,
    trivia: [
      { id: "az1", question: "What was Azcapotzalco historically known as before Spanish colonization?", options: ["An Aztec capital", "Capital of the Tepanec Empire", "A Mayan city", "A Spanish fortress"], correctAnswer: 1, difficulty: 'easy', category: 'misc' },
      { id: "az2", question: "What does 'Azcapotzalco' mean in Nahuatl?", options: ["Place of eagles", "Place of ants on the hill", "City of gold", "Market of flowers"], correctAnswer: 1, difficulty: 'medium', category: 'misc' },
      { id: "az3", question: "Who conquered the Tepanec capital of Azcapotzalco?", options: ["The Mayans", "Moctezuma I", "Itzcoatl and the Aztecs", "The Spanish"], correctAnswer: 2, difficulty: 'hard', category: 'crimes' },
    ]
  },
  {
    id: 3, name: "Miguel Hidalgo", subtitle: "Polanco", level: 'tourist',
    color: '#3B82F6', icon: '🏰',
    description: "An upscale district featuring Chapultepec Castle, the National Museum of Anthropology, and luxury shopping on Paseo de la Reforma.",
    funFact: "Chapultepec Park is twice the size of Central Park in New York City.",
    mapX: 32, mapY: 28,
    trivia: [
      { id: "m1", question: "Chapultepec Castle is located in which district of Mexico City?", options: ["Cuauhtémoc", "Miguel Hidalgo", "Coyoacán", "Benito Juárez"], correctAnswer: 1, difficulty: 'easy', category: 'landmarks' },
      { id: "m2", question: "What is the name of the famous avenue that runs through Miguel Hidalgo with monuments and fountains?", options: ["Avenida Insurgentes", "Paseo de la Reforma", "Calzada de Tlalpan", "Avenida Juárez"], correctAnswer: 1, difficulty: 'medium', category: 'geography' },
      { id: "m3", question: "How does Chapultepec Park's size compare to Central Park in New York?", options: ["Half the size", "Same size", "Twice the size", "Three times larger"], correctAnswer: 2, difficulty: 'hard', category: 'geography' },
    ]
  },
  {
    id: 4, name: "Cuajimalpa", subtitle: "", level: 'tourist',
    color: '#3B82F6', icon: '🌲',
    description: "A mountainous western district that borders the State of Mexico, home to Santa Fe business district and dense forests.",
    funFact: "Cuajimalpa is home to one of the last remaining forests within Mexico City limits.",
    mapX: 16, mapY: 38,
    trivia: [
      { id: "cu1", question: "What modern business hub is located in Cuajimalpa de Morelos?", options: ["Polanco", "Santa Fe", "San Ángel", "Coyoacán"], correctAnswer: 1, difficulty: 'easy', category: 'landmarks' },
      { id: "cu2", question: "What natural feature distinguishes Cuajimalpa from most other Mexico City districts?", options: ["It has a beach", "It has dense mountain forests", "It has a desert", "It has a volcano"], correctAnswer: 1, difficulty: 'medium', category: 'geography' },
      { id: "cu3", question: "Cuajimalpa borders which neighboring state?", options: ["Puebla", "Morelos", "State of Mexico", "Hidalgo"], correctAnswer: 2, difficulty: 'hard', category: 'geography' },
    ]
  },
  {
    id: 5, name: "Álvaro Obregón", subtitle: "Santa Fe", level: 'tourist',
    color: '#3B82F6', icon: '🏢',
    description: "A western district with the San Ángel neighborhood and Santa Fe business district, famous for its Saturday art bazaar.",
    funFact: "The San Ángel Art Bazaar has been running since 1932 and features over 800 artists.",
    mapX: 26, mapY: 44,
    trivia: [
      { id: "a1", question: "What famous weekly art event takes place in the San Ángel area?", options: ["Sunday Art Market", "San Ángel Art Bazaar", "Frida Kahlo Fair", "Mexican Craft Show"], correctAnswer: 1, difficulty: 'easy', category: 'misc' },
      { id: "a2", question: "Since what year has the San Ángel Art Bazaar been operating?", options: ["1900", "1932", "1950", "1968"], correctAnswer: 1, difficulty: 'medium', category: 'misc' },
      { id: "a3", question: "How many artists typically participate in the San Ángel Art Bazaar?", options: ["100", "300", "500", "800+"], correctAnswer: 3, difficulty: 'hard', category: 'misc' },
    ]
  },
  {
    id: 6, name: "Magdalena Contreras", subtitle: "", level: 'tourist',
    color: '#3B82F6', icon: '🏔️',
    description: "A southern district known for the Desierto de los Leones National Park and its colonial-era Carmelite monastery.",
    funFact: "Desierto de los Leones (Desert of the Lions) is actually a forest, not a desert.",
    mapX: 22, mapY: 60,
    trivia: [
      { id: "l1", question: "What famous national park is located in La Magdalena Contreras?", options: ["Bosque de Chapultepec", "Desierto de los Leones", "Cumbres del Ajusco", "Silmayo"], correctAnswer: 1, difficulty: 'easy', category: 'landmarks' },
      { id: "l2", question: "Despite its name, what is the 'Desierto de los Leones' actually like?", options: ["A sandy desert", "A dense forest", "A mountain lake", "A volcanic crater"], correctAnswer: 1, difficulty: 'medium', category: 'geography' },
      { id: "l3", question: "What order of monks built the 17th-century monastery in the park?", options: ["Franciscans", "Carmelites", "Jesuits", "Dominicans"], correctAnswer: 1, difficulty: 'hard', category: 'misc' },
    ]
  },
  // ─── Step 7: Sur (Green) ───────────────────────────────────────
  {
    id: 7, name: "Benito Juárez", subtitle: "Roma / Condesa", level: 'city',
    color: '#22C55E', icon: '🌳',
    description: "A modern business and residential district with parks, the World Trade Center, and the National Auditorium.",
    funFact: "The National Auditorium in Benito Juárez has been named the best venue in the world multiple times.",
    mapX: 44, mapY: 42,
    trivia: [
      { id: "b1", question: "What famous modern structure in Benito Juárez has hosted international concerts and events?", options: ["Palacio de Bellas Artes", "National Auditorium", "Aztec Stadium", "Torre Mayor"], correctAnswer: 1, difficulty: 'easy', category: 'landmarks' },
      { id: "b2", question: "Benito Juárez is named after a president who was from which Mexican state?", options: ["Jalisco", "Oaxaca", "Puebla", "Veracruz"], correctAnswer: 1, difficulty: 'medium', category: 'misc' },
      { id: "b3", question: "Which large park in Benito Juárez is known for its bike paths and green spaces?", options: ["Chapultepec", "Parque Hundido", "Parque México", "Bosque de Aragón"], correctAnswer: 1, difficulty: 'hard', category: 'geography' },
    ]
  },
  {
    id: 8, name: "Coyoacán", subtitle: "", level: 'city',
    color: '#22C55E', icon: '🎨',
    description: "A bohemian neighborhood known for its colonial architecture, the Frida Kahlo Museum, and vibrant cultural scene.",
    funFact: "Frida Kahlo's famous 'Casa Azul' (Blue House) is located in Coyoacán and is now a museum.",
    mapX: 42, mapY: 52,
    trivia: [
      { id: "co1", question: "Which famous Mexican artist's Blue House museum is in Coyoacán?", options: ["Diego Rivera", "Frida Kahlo", "Remedios Varo", "Leonora Carrington"], correctAnswer: 1, difficulty: 'easy', category: 'misc' },
      { id: "co2", question: "Coyoacán was once a separate town. What does its name mean in Nahuatl?", options: ["Place of monkeys", "Place of coyotes", "Place of flowers", "Place of eagles"], correctAnswer: 1, difficulty: "medium", category: 'misc' },
      { id: "co3", question: "Which UNESCO World Heritage campus is partially located in Coyoacán?", options: ["UNAM Main Campus", "IPN Campus", "ITESM Campus", "UAM Campus"], correctAnswer: 0, difficulty: 'hard', category: 'landmarks' },
    ]
  },
  {
    id: 9, name: "Tlalpan", subtitle: "", level: 'city',
    color: '#22C55E', icon: '⛰️',
    description: "The largest district by area, featuring the UNAM main campus, the Pedregal lava fields, and Mount Ajusco.",
    funFact: "Tlalpan contains the Pedregal de San Ángel, a unique ecosystem formed by ancient volcanic lava flows.",
    mapX: 38, mapY: 72,
    trivia: [
      { id: "t1", question: "Which major university has its main campus in Tlalpan?", options: ["UNAM", "IPN", "ITESM", "UAM"], correctAnswer: 0, difficulty: 'easy', category: 'landmarks' },
      { id: "t2", question: "What unique geological feature is found in Tlalpan's San Ángel area?", options: ["Ancient lava fields", "A freshwater lake", "Sand dunes", "Crystal caves"], correctAnswer: 0, difficulty: 'medium', category: 'geography' },
      { id: "t3", question: "Mount Ajusco, the highest point in Mexico City, is in which district?", options: ["Coyoacán", "Tlalpan", "La Magdalena Contreras", "Álvaro Obregón"], correctAnswer: 1, difficulty: 'hard', category: 'geography' },
    ]
  },
  // ─── Step 10: Oriente (Yellow) ─────────────────────────────────
  {
    id: 10, name: "Xochimilco", subtitle: "", level: 'emergency',
    color: '#EAB308', icon: '🚣',
    description: "Famous for its UNESCO World Heritage canals and colorful trajinera boats, a remnant of the Aztec lake system.",
    funFact: "Xochimilco's canals are the last surviving remnants of the vast lake system that once covered the Valley of Mexico.",
    mapX: 55, mapY: 64,
    trivia: [
      { id: "x1", question: "What are the colorful boats on Xochimilco's canals called?", options: ["Canoes", "Trajineras", "Kayaks", "Gondolas"], correctAnswer: 1, difficulty: 'easy', category: 'misc' },
      { id: "x2", question: "Why is Xochimilco a UNESCO World Heritage Site?", options: ["Its canals and floating gardens", "Its ancient pyramids", "Its colonial churches", "Its volcanic landscape"], correctAnswer: 0, difficulty: 'medium', category: 'landmarks' },
      { id: "x3", question: "Xochimilco's canals are the last remnants of what ancient system?", options: ["Aztec irrigation system", "Aztec lake system", "Spanish aqueducts", "Mayan reservoirs"], correctAnswer: 1, difficulty: 'hard', category: 'misc' },
    ]
  },
  {
    id: 11, name: "Milpa Alta", subtitle: "", level: 'emergency',
    color: '#EAB308', icon: '🌵',
    description: "The most rural district in the city, known for its corn and nopal cultivation, traditional festivals, and strong indigenous Nahuatl heritage.",
    funFact: "Milpa Alta produces over 50% of the nopal (cactus) consumed in all of Mexico City.",
    mapX: 62, mapY: 82,
    trivia: [
      { id: "mi1", question: "What makes Milpa Alta unique among Mexico City's districts?", options: ["It has the tallest buildings", "It's the most rural district", "It has the most immigrants", "It has no parks"], correctAnswer: 1, difficulty: 'easy', category: 'geography' },
      { id: "mi2", question: "Milpa Alta is famous for producing large amounts of which food?", options: ["Tomatoes", "Nopal (cactus)", "Corn", "Avocados"], correctAnswer: 1, difficulty: 'medium', category: 'misc' },
      { id: "mi3", question: "What indigenous language is still widely spoken in Milpa Alta?", options: ["Zapotec", "Mixtec", "Nahuatl", "Maya"], correctAnswer: 2, difficulty: 'hard', category: 'misc' },
    ]
  },
  {
    id: 12, name: "Tláhuac", subtitle: "", level: 'emergency',
    color: '#EAB308', icon: '🌾',
    description: "An eastern district known for its traditional agriculture, chinampas (floating gardens), and the Lago de los Reyes Aztecas.",
    funFact: "Tláhuac still produces crops using chinampas, an ancient Aztec farming method that predates Columbus.",
    mapX: 68, mapY: 56,
    trivia: [
      { id: "tl1", question: "What ancient farming technique is still practiced in Tláhuac?", options: ["Terrace farming", "Chinampas (floating gardens)", "Irrigation channels", "Slash and burn"], correctAnswer: 1, difficulty: 'easy', category: 'misc' },
      { id: "tl2", question: "Chinampas are also known as what?", options: ["Water gardens", "Floating gardens", "Island farms", "Lake farms"], correctAnswer: 1, difficulty: 'medium', category: 'misc' },
      { id: "tl3", question: "What lake system is partially preserved in Tláhuac?", options: ["Lake Texcoco", "Lago de los Reyes Aztecas", "Lake Patzcuaro", "Lake Chapala"], correctAnswer: 1, difficulty: 'hard', category: 'geography' },
    ]
  },
  {
    id: 13, name: "Iztapalapa", subtitle: "", level: 'emergency',
    color: '#EAB308', icon: '⛪',
    description: "The most populous district in Mexico City, famous for its massive Passion Play reenactment every Easter.",
    funFact: "Iztapalapa's Passion Play is the largest in the world, with over 4,000 actors.",
    mapX: 64, mapY: 42,
    trivia: [
      { id: "iz1", question: "What makes Iztapalapa unique among Mexico City's districts?", options: ["It's the smallest", "It's the most populous", "It's the richest", "It's the oldest"], correctAnswer: 1, difficulty: 'easy', category: 'geography' },
      { id: "iz2", question: "What famous Easter event is Iztapalapa known for?", options: ["Day of the Dead parade", "Passion Play reenactment", "Independence Day celebration", "Carnival parade"], correctAnswer: 1, difficulty: 'medium', category: 'crimes' },
      { id: "iz3", question: "Approximately how many actors participate in Iztapalapa's Passion Play?", options: ["500", "1,000", "4,000", "10,000"], correctAnswer: 2, difficulty: 'hard', category: 'misc' },
    ]
  },
  // ─── Step 14: Norte (Red) ──────────────────────────────────────
  {
    id: 14, name: "Iztacalco", subtitle: "", level: 'victory',
    color: '#EF4444', icon: '🏟️',
    description: "The smallest district by area, known for its hockey stadium, textile industry, and the Iztacalco Community Museum.",
    funFact: "Iztacalco means 'House of White Salt' in Nahuatl.",
    mapX: 58, mapY: 32,
    trivia: [
      { id: "i1", question: "What is Iztacalco known as in terms of size among Mexico City districts?", options: ["The largest", "The smallest", "The oldest", "The newest"], correctAnswer: 1, difficulty: 'easy', category: 'geography' },
      { id: "i2", question: "What does 'Iztacalco' mean in the Nahuatl language?", options: ["White hill", "House of White Salt", "Sacred water", "Market of stone"], correctAnswer: 1, difficulty: 'medium', category: 'misc' },
      { id: "i3", question: "Which sport's stadium is a major landmark in Iztacalco?", options: ["Football", "Baseball", "Ice Hockey", "Basketball"], correctAnswer: 2, difficulty: 'hard', category: 'landmarks' },
    ]
  },
  {
    id: 15, name: "Venustiano Carranza", subtitle: "Aeropuerto", level: 'victory',
    color: '#EF4444', icon: '✈️',
    description: "Home to the bustling Mercado de la Merced, Mexico City International Airport, and the historic Market of San Juan.",
    funFact: "Mercado de la Merced is the largest traditional market in Latin America.",
    mapX: 60, mapY: 24,
    trivia: [
      { id: "v1", question: "Which major international airport is located in Venustiano Carranza?", options: ["Toluca Airport", "Benito Juárez International Airport", "Felipe Ángeles Airport", "San Luis Potosí Airport"], correctAnswer: 1, difficulty: 'easy', category: 'landmarks' },
      { id: "v2", question: "What is the largest traditional market in Latin America, found in this district?", options: ["Mercado de San Juan", "Mercado de la Merced", "Mercado de Jamaica", "Mercado de Sonora"], correctAnswer: 1, difficulty: 'medium', category: 'misc' },
      { id: "v3", question: "Venustiano Carranza was a key figure in which major Mexican historical event?", options: ["Mexican Revolution", "Independence War", "French Intervention", "Mexican-American War"], correctAnswer: 0, difficulty: 'hard', category: 'crimes' },
    ]
  },
  {
    id: 16, name: "Gustavo A. Madero", subtitle: "", level: 'victory',
    color: '#EF4444', icon: '⛪',
    description: "A densely populated northern district with the Basilica of Our Lady of Guadalupe, one of the most visited religious sites in the world.",
    funFact: "The Basilica of Guadalupe receives about 10 million visitors per year, more than the Vatican.",
    mapX: 54, mapY: 10,
    trivia: [
      { id: "g1", question: "What world-famous religious site is located in Gustavo A. Madero?", options: ["Cathedral of Mexico City", "Basilica of Our Lady of Guadalupe", "Church of San Francisco", "Temple of San Agustín"], correctAnswer: 1, difficulty: 'easy', category: 'landmarks' },
      { id: "g2", question: "How many visitors does the Basilica of Guadalupe receive annually?", options: ["About 2 million", "About 5 million", "About 10 million", "About 20 million"], correctAnswer: 2, difficulty: 'medium', category: 'geography' },
      { id: "g3", question: "The Tepeyac Hill, where the Virgin appeared, is in which district?", options: ["Coyoacán", "Tlalpan", "Gustavo A. Madero", "Azcapotzalco"], correctAnswer: 2, difficulty: 'hard', category: 'misc' },
    ]
  },
];

export const getDistrictById = (id: number): District | undefined => {
  return districts.find(d => d.id === id);
};

export const getRandomQuestion = (district: District): TriviaQuestion => {
  const idx = Math.floor(Math.random() * district.trivia.length);
  return district.trivia[idx];
};

export const getQuestionsByDifficulty = (district: District, difficulty: 'easy' | 'medium' | 'hard'): TriviaQuestion[] => {
  return district.trivia.filter(q => q.difficulty === difficulty);
};
