import { useGameStore } from '../store/gameStore';
import { districts, levels, patrolRoute } from '../data/districts';

const zoneColors: Record<string, { bg: string; text: string; label: string }> = {
  start: { bg: 'rgba(232,228,223,0.1)', text: '#e8e4df', label: 'CENTRO' },
  tourist: { bg: 'rgba(45,107,196,0.1)', text: '#4a8ae0', label: 'PONIENTE' },
  city: { bg: 'rgba(61,139,79,0.1)', text: '#5aab6f', label: 'SUR' },
  emergency: { bg: 'rgba(201,168,37,0.1)', text: '#e0c040', label: 'ORIENTE' },
  victory: { bg: 'rgba(196,61,61,0.1)', text: '#e05555', label: 'NORTE' },
};

export default function DistrictInfo() {
  const { currentPlayerIndex, players, phase } = useGameStore();

  if (phase === 'setup' || phase === 'gameover') return null;

  const player = players[currentPlayerIndex];
  if (!player) return null;

  const district = districts.find(d => d.id === player.currentDistrictId);
  if (!district) return null;

  const level = levels[district.level];
  const zone = zoneColors[district.level];

  return (
    <div className="glass-card rounded-xl p-4 w-full">
      <div className="flex items-center gap-2 mb-2">
        <div
          className="w-3 h-3 rounded-full border border-white/20"
          style={{ backgroundColor: district.color === '#FFFFFF' ? '#e8e4df' : district.color }}
        />
        <p className="text-white font-bold text-sm">{district.name}</p>
        <span className="text-th-muted text-[10px] ml-auto">
          {district.id}/16
        </span>
      </div>
      <div className="flex items-center gap-1.5 mb-2">
        <span
          className="text-[10px] px-2 py-0.5 rounded font-bold"
          style={{ backgroundColor: zone.bg, color: zone.text }}
        >
          {zone.label}
        </span>
      </div>
      <p className="text-th-secondary text-[11px] leading-relaxed">
        {district.description}
      </p>
    </div>
  );
}
