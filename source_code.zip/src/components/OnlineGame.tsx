import { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRoomStore } from '../store/roomStore';
import { useRoomSync } from '../store/useRoomSync';
import { useGameStore } from '../store/gameStore';
import { useTheme } from '../store/themeContext';
import GameBoard from './GameBoard';
import PlayerPanel from './PlayerPanel';
import DistrictInfo from './DistrictInfo';
import GameOver from './GameOver';
import cdmxBadge from '../assets/cdmx-badge.png';
import { districts, patrolRoute } from '../data/districts';

const colorMeta: Record<string, { icon: string; hex: string }> = {
  car: { icon: '🚔', hex: '#2d6bc4' },
  moto: { icon: '🏍️', hex: '#c43d3d' },
  bike: { icon: '🚲', hex: '#f5e642' },
  horse: { icon: '🐴', hex: '#3d8b4f' },
  foot: { icon: '🚶', hex: '#c8956c' },
};

const difficultyConfig = [
  { level: 'easy' as const, label: 'Easy', points: 10, color: '#3d8b4f', emoji: '🟢' },
  { level: 'medium' as const, label: 'Medium', points: 20, color: '#c9a825', emoji: '🟡' },
  { level: 'hard' as const, label: 'Hard', points: 30, color: '#c43d3d', emoji: '🔴' },
];

const categoryEmoji: Record<string, string> = {
  geography: '🌍',
  landmarks: '🏛️',
  crimes: '🚔',
  english: '🔤',
  misc: '📋',
};

export default function OnlineGame({ onLeave }: { onLeave: () => void }) {
  const { roomCode, isHost, gameState, myPlayerId } = useRoomStore();
  const { hostStartGame, sendAction } = useRoomSync();
  const syncFromRemote = useGameStore((s) => s.syncFromRemote);
  const { theme, toggleTheme } = useTheme();
  const [copied, setCopied] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(10);

  const players = gameState?.players ?? [];
  const phase = gameState?.phase ?? 'lobby';
  const roundNumber = gameState?.roundNumber ?? 0;
  const currentDistrictId = gameState?.currentDistrictId ?? 12;
  const difficultyChooserId = gameState?.difficultyChooserId ?? null;
  const currentQuestion = gameState?.currentQuestion ?? null;
  const currentDifficulty = gameState?.currentDifficulty ?? null;
  const answers = gameState?.answers ?? {};
  const timerEnd = gameState?.timerEnd ?? null;
  const showResult = gameState?.showResult ?? false;

  const isMyChooser = difficultyChooserId === myPlayerId;
  const myAnswer = answers[myPlayerId];
  const hasAnswered = myPlayerId in answers;
  const allAnswered = players.length > 0 && players.every((p) => p.id in answers);
  const myPlayer = players.find((p) => p.id === myPlayerId);
  const district = districts.find((d) => d.id === currentDistrictId);

  // Reset selected option when question changes
  useEffect(() => {
    setSelectedOption(null);
  }, [currentQuestion?.id]);

  // Countdown timer
  useEffect(() => {
    if (phase !== 'trivia' || !timerEnd) {
      setTimeLeft(30);
      return;
    }
    const update = () => {
      const remaining = Math.max(0, Math.ceil((timerEnd - Date.now()) / 1000));
      setTimeLeft(remaining);
    };
    update();
    const interval = setInterval(update, 200);
    return () => clearInterval(interval);
  }, [phase, timerEnd]);

  // Mirror the remote authoritative state into the local gameStore so
  // GameBoard / PlayerPanel / DistrictInfo components can render.
  useEffect(() => {
    if (!gameState) return;
    syncFromRemote({
      players: gameState.players as any,
      // Map the shared round state to what components expect
      currentPlayerIndex: 0,
      phase: gameState.phase === 'lobby' ? 'setup' : gameState.phase === 'roundResult' ? 'trivia' : gameState.phase,
      currentQuestion: gameState.currentQuestion,
      selectedAnswer: hasAnswered ? myAnswer ?? null : null,
      showResult: gameState.showResult,
      isCorrect: hasAnswered && showResult && currentQuestion
        ? myAnswer === currentQuestion.correctAnswer
        : null,
      gameLog: gameState.gameLog,
    });
  }, [gameState, syncFromRemote, hasAnswered, myAnswer, showResult, currentQuestion]);

  const inviteUrl = `${window.location.origin}${window.location.pathname}?room=${roomCode}`;

  const copyInvite = async () => {
    try {
      await navigator.clipboard.writeText(inviteUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch { /* ignore */ }
  };

  const handleChooseDifficulty = (difficulty: 'easy' | 'medium' | 'hard') => {
    sendAction('chooseDifficulty', { difficulty });
  };

  const handleSubmitAnswer = (answerIndex: number) => {
    if (hasAnswered || phase !== 'trivia') return;
    setSelectedOption(answerIndex);
    sendAction('submitAnswer', { answerIndex });
  };

  const handleNextRound = () => {
    sendAction('nextRound');
  };

  // ─── Waiting room (lobby) ───
  if (phase === 'lobby') {
    return (
      <div className="min-h-screen bg-gradient-warm flex items-center justify-center p-4 relative overflow-hidden noise-overlay">
        <button onClick={toggleTheme} className="theme-toggle fixed top-5 right-5 z-50" title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}>
          {theme === 'dark' ? '☀️' : '🌙'}
        </button>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-lg relative z-10"
        >
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-2xl overflow-hidden shadow-2xl mx-auto mb-4">
              <img src={cdmxBadge} alt="CDMX" className="w-full h-full object-cover" />
            </div>
            <h1 className="font-display text-4xl text-th-primary tracking-wider">WAITING ROOM</h1>
            <p className="text-th-secondary text-sm mt-1">Share the code — players join from their own devices</p>
          </div>

          <div className="glass-card rounded-2xl p-6">
            {/* Room code */}
            <div className="text-center mb-5">
              <p className="text-th-secondary text-[11px] uppercase tracking-widest font-bold mb-2">Room Code</p>
              <div className="text-5xl font-display tracking-[0.3em] text-white pl-3" style={{ color: '#c8956c' }}>
                {roomCode}
              </div>
            </div>

            {/* Invite link */}
            <div className="flex gap-2 mb-5">
              <input
                readOnly
                value={inviteUrl}
                className="flex-1 bg-white/[0.04] border border-white/[0.08] rounded-xl px-3 py-2.5 text-th-secondary text-xs focus:outline-none truncate"
              />
              <button
                onClick={copyInvite}
                className="px-4 py-2.5 btn-primary rounded-xl text-xs font-bold whitespace-nowrap transition-all"
              >
                {copied ? '✓ Copied' : 'Copy Link'}
              </button>
            </div>

            {/* Players */}
            <p className="text-th-secondary text-[11px] uppercase tracking-widest font-bold mb-2">
              Cadets ({players.length}/5)
            </p>
            <div className="space-y-2 mb-5">
              {players.map((p) => (
                <div key={p.id} className="flex items-center gap-3 bg-white/[0.04] rounded-xl px-4 py-3 border border-white/[0.06]">
                  <div
                    className="w-9 h-9 rounded-full flex items-center justify-center text-base shadow-md"
                    style={{ backgroundColor: colorMeta[p.color]?.hex }}
                  >
                    {colorMeta[p.color]?.icon}
                  </div>
                  <span className="text-th-primary text-sm font-medium flex-1">{p.name}</span>
                  {p.id === myPlayerId && <span className="text-[10px] text-th-secondary font-bold uppercase">You</span>}
                  {gameState?.players[0]?.id === p.id && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#c8956c]/20 text-[#c8956c] font-bold">Host</span>
                  )}
                </div>
              ))}
              {players.length < 5 &&
                Array.from({ length: 5 - players.length }).map((_, i) => (
                  <div key={`empty-${i}`} className="flex items-center gap-3 bg-white/[0.02] rounded-xl px-4 py-3 border border-dashed border-white/[0.06]">
                    <div className="w-9 h-9 rounded-full bg-white/[0.04] flex items-center justify-center text-th-muted">?</div>
                    <span className="text-th-muted text-sm">Waiting for a player…</span>
                  </div>
                ))}
            </div>

            {isHost ? (
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={hostStartGame}
                disabled={players.length < 1}
                className="w-full px-5 py-3.5 btn-primary disabled:bg-white/10 disabled:text-white/20 rounded-xl text-sm font-bold transition-all"
              >
                🚨 Start Patrol ({players.length} {players.length === 1 ? 'player' : 'players'})
              </motion.button>
            ) : (
              <div className="text-center text-th-secondary text-sm py-3">
                Waiting for the host to start the game…
              </div>
            )}

            <button onClick={onLeave} className="w-full mt-3 px-5 py-2.5 rounded-xl text-xs text-th-secondary hover:text-th-primary transition-all">
              Leave room
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  // ─── Game over ───
  if (phase === 'gameover') {
    return <GameOver onNewGame={onLeave} />;
  }

  // ─── Playing / Trivia / Round Result ───
  return (
    <div className="min-h-screen bg-gradient-warm text-white flex flex-col noise-overlay relative">
      {/* Header */}
      <header className="px-5 py-3 flex items-center justify-between border-b border-white/[0.06] bg-black/20 backdrop-blur-md flex-shrink-0 relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl overflow-hidden shadow-lg flex-shrink-0">
            <img src={cdmxBadge} alt="CDMX" className="w-full h-full object-cover" />
          </div>
          <div>
            <h1 className="font-display text-xl tracking-wide text-th-primary leading-none">CDMX PATROL</h1>
            <p className="text-[10px] text-th-secondary tracking-widest uppercase">
              Online · Room {roomCode} · Round {roundNumber + 1}/16
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* Timer badge during trivia */}
          {phase === 'trivia' && (
            <motion.span
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className={`text-sm font-bold px-3 py-1.5 rounded-lg font-display ${
                timeLeft <= 3
                  ? 'bg-[#c43d3d]/30 text-[#e05555] animate-pulse'
                  : 'bg-white/[0.08] text-th-secondary'
              }`}
            >
              ⏱ {timeLeft}s
            </motion.span>
          )}
          <button onClick={onLeave} className="px-3 py-1.5 text-xs text-th-secondary hover:text-th-primary hover:bg-white/[0.06] rounded-lg transition-all font-medium">
            Leave
          </button>
        </div>
      </header>

      <div className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden">
        {/* Left sidebar — Player scores */}
        <aside className="w-full lg:w-64 p-3 order-2 lg:order-1 overflow-y-auto flex-shrink-0 lg:h-full">
          <PlayerPanel />
        </aside>

        {/* Center — Game board */}
        <main className="flex-1 flex flex-col p-3 order-1 lg:order-2 min-h-0 overflow-hidden">
          <GameBoard />
        </main>

        {/* Right sidebar — Game action area */}
        <aside className="w-full lg:w-80 p-3 order-3 overflow-y-auto flex-shrink-0 lg:h-full flex flex-col items-center gap-3">
          {/* Borough info */}
          <DistrictInfo />

          {/* Phase: Playing — Difficulty chooser */}
          {phase === 'playing' && (
            <div className="glass-card rounded-2xl p-5 text-center w-full">
              <p className="text-th-secondary text-[11px] uppercase tracking-widest font-bold mb-2 font-display">
                Round {roundNumber + 1}/16
              </p>
              <div className="flex items-center justify-center gap-2 mb-4">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-md"
                  style={{ backgroundColor: district?.color === '#FFFFFF' ? '#e8e4df' : district?.color }}
                >
                  {district?.icon}
                </div>
                <div className="text-left">
                  <p className="text-white font-bold text-sm leading-tight">
                    #{currentDistrictId} {district?.name}
                  </p>
                  {district?.subtitle && (
                    <p className="text-th-muted text-[10px]">{district.subtitle}</p>
                  )}
                </div>
              </div>

              {isMyChooser ? (
                <>
                  <p className="text-[#c8956c] text-[11px] font-bold mb-3">
                    🎯 You choose the difficulty!
                  </p>
                  <div className="flex gap-2">
                    {difficultyConfig.map((diff) => (
                      <motion.button
                        key={diff.level}
                        whileHover={{ scale: 1.03, y: -1 }}
                        whileTap={{ scale: 0.97 }}
                        onClick={() => handleChooseDifficulty(diff.level)}
                        className="flex-1 py-3 rounded-xl text-sm font-bold transition-all flex flex-col items-center gap-1"
                        style={{ backgroundColor: `${diff.color}20`, border: `1px solid ${diff.color}40`, color: diff.color }}
                      >
                        <span className="text-lg leading-none">{diff.emoji}</span>
                        <span>{diff.label}</span>
                        <span className="text-[10px] opacity-70">+{diff.points} pts</span>
                      </motion.button>
                    ))}
                  </div>
                </>
              ) : (
                <p className="text-th-secondary text-sm">
                  Waiting for {players.find((p) => p.id === difficultyChooserId)?.name ?? 'a player'} to choose difficulty…
                </p>
              )}
            </div>
          )}

          {/* Phase: Trivia — Question + answers */}
          {phase === 'trivia' && currentQuestion && (
            <div className="w-full">
              <OnlineTriviaCard
                question={currentQuestion}
                district={district}
                difficulty={currentDifficulty}
                hasAnswered={hasAnswered}
                myAnswer={myAnswer ?? null}
                showResult={showResult}
                timeLeft={timeLeft}
                answers={answers}
                players={players}
                onSelectAnswer={handleSubmitAnswer}
              />
            </div>
          )}

          {/* Phase: Round Result */}
          {phase === 'roundResult' && currentQuestion && (
            <div className="w-full">
              <RoundResultCard
                question={currentQuestion}
                district={district}
                difficulty={currentDifficulty}
                answers={answers}
                players={players}
                myPlayerId={myPlayerId}
                isMyChooser={isMyChooser}
                onNextRound={handleNextRound}
              />
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}

// ─── Online Trivia Card (simultaneous question for all players) ───
function OnlineTriviaCard({
  question,
  district,
  difficulty,
  hasAnswered,
  myAnswer,
  showResult,
  timeLeft,
  answers,
  players,
  onSelectAnswer,
}: {
  question: any;
  district: any;
  difficulty: string | null;
  hasAnswered: boolean;
  myAnswer: number | null;
  showResult: boolean;
  timeLeft: number;
  answers: Record<string, number>;
  players: any[];
  onSelectAnswer: (idx: number) => void;
}) {
  const diffConfig = difficulty === 'hard'
    ? { bg: 'rgba(196,61,61,0.1)', text: '#e05555', border: 'rgba(196,61,61,0.2)' }
    : difficulty === 'medium'
    ? { bg: 'rgba(201,168,37,0.1)', text: '#e0c040', border: 'rgba(201,168,37,0.2)' }
    : { bg: 'rgba(61,139,79,0.1)', text: '#5aab6f', border: 'rgba(61,139,79,0.2)' };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: 'spring', stiffness: 300, damping: 25 }}
    >
      <div className="glass-card rounded-2xl overflow-hidden">
        {/* Header */}
        <div className="px-4 py-3 flex items-center justify-between border-b border-white/[0.06]">
          <div className="flex items-center gap-2">
            <span className="text-sm">
              {district?.icon} {categoryEmoji[question.category]}{' '}
              <span className="text-th-secondary text-[10px] font-bold capitalize">{question.category}</span>
            </span>
            <span className="text-th-primary font-bold text-xs">#{district?.id} {district?.name}</span>
          </div>
          <div className="flex items-center gap-2">
            <span
              className="px-2 py-0.5 rounded text-[10px] font-bold border"
              style={{ backgroundColor: diffConfig.bg, color: diffConfig.text, borderColor: diffConfig.border }}
            >
              {difficulty?.toUpperCase()}
            </span>
            <span className="text-[10px] font-bold" style={{ color: '#c8956c' }}>
              +{difficulty === 'easy' ? 10 : difficulty === 'medium' ? 20 : 30} pts
            </span>
          </div>
        </div>

        {/* Timer bar */}
        <div className="px-4 pt-3">
          <div className="w-full h-1.5 bg-white/[0.06] rounded-full overflow-hidden">
            <motion.div
              className="h-full rounded-full"
              style={{
                backgroundColor: timeLeft <= 3 ? '#c43d3d' : timeLeft <= 6 ? '#c9a825' : '#3d8b4f',
              }}
              initial={{ width: '100%' }}
              animate={{ width: `${(timeLeft / 10) * 100}%` }}
              transition={{ duration: 0.2 }}
            />
          </div>
        </div>

        {/* Question */}
        <div className="px-4 py-3">
          <h3 className="text-sm font-bold text-th-primary leading-snug">
            {question.question}
          </h3>
        </div>

        {/* Options */}
        <div className="px-4 pb-3 grid gap-2">
          {question.options.map((option: string, idx: number) => {
            const isSelected = myAnswer === idx;
            const isCorrectAnswer = idx === question.correctAnswer;
            let optionStyle = 'bg-white/[0.03] border-white/[0.06] hover:border-[#c8956c]/30 hover:bg-white/[0.06]';

            if (hasAnswered || showResult) {
              // Lock the button after answering
              optionStyle = 'bg-white/[0.02] border-white/[0.04] opacity-60 cursor-default';
              if (isSelected) {
                optionStyle = 'bg-[#c8956c]/10 border-[#c8956c]/40 ring-1 ring-[#c8956c]/20';
              }
            }

            return (
              <motion.button
                key={idx}
                whileHover={!hasAnswered ? { scale: 1.01 } : undefined}
                whileTap={!hasAnswered ? { scale: 0.99 } : undefined}
                onClick={() => !hasAnswered && onSelectAnswer(idx)}
                disabled={hasAnswered}
                className={`text-left px-4 py-3 rounded-xl border text-sm font-medium transition-all ${optionStyle}`}
              >
                <span className="text-th-primary">
                  <span className="text-th-muted mr-2">{String.fromCharCode(65 + idx)}.</span>
                  {option}
                </span>
                {isSelected && (
                  <span className="ml-2 text-[#c8956c]">●</span>
                )}
              </motion.button>
            );
          })}
        </div>

        {/* Status */}
        <div className="px-4 pb-4">
          {hasAnswered && !showResult && (
            <div className="text-center py-2 rounded-xl bg-[#c8956c]/10 border border-[#c8956c]/20">
              <p className="text-[#c8956c] text-xs font-bold">✓ Answer submitted — waiting for others…</p>
            </div>
          )}
          {/* Who has answered */}
          {!showResult && (
            <div className="flex items-center justify-center gap-1.5 mt-2 flex-wrap">
              {players.map((p) => {
                const answered = p.id in answers;
                return (
                  <span
                    key={p.id}
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                      answered
                        ? 'bg-[#3d8b4f]/20 text-[#5aab6f]'
                        : 'bg-white/[0.04] text-th-muted'
                    }`}
                  >
                    {answered ? '✓' : '⏳'} {p.name}
                  </span>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

// ─── Round Result Card ───
function RoundResultCard({
  question,
  district,
  difficulty,
  answers,
  players,
  myPlayerId,
  isMyChooser,
  onNextRound,
}: {
  question: any;
  district: any;
  difficulty: string | null;
  answers: Record<string, number>;
  players: any[];
  myPlayerId: string;
  isMyChooser: boolean;
  onNextRound: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: 'spring', stiffness: 300, damping: 25 }}
    >
      <div className="glass-card rounded-2xl overflow-hidden">
        {/* Header */}
        <div className="px-4 py-3 border-b border-white/[0.06] text-center">
          <p className="text-th-secondary text-[11px] uppercase tracking-widest font-bold font-display">
            Round Results
          </p>
          <p className="text-th-primary font-bold text-sm mt-1">
            {district?.icon} #{district?.id} {district?.name}
          </p>
        </div>

        {/* Correct answer */}
        <div className="px-4 py-3">
          <div className="rounded-xl p-3 bg-[#3d8b4f]/10 border border-[#3d8b4f]/20 mb-3">
            <p className="text-[#5aab6f] text-xs font-bold mb-1">Correct Answer</p>
            <p className="text-th-primary text-sm font-medium">
              {question.options[question.correctAnswer]}
            </p>
          </div>
        </div>

        {/* Player results */}
        <div className="px-4 pb-3 space-y-2">
          {players.map((p) => {
            const answerIdx = answers[p.id];
            const correct = answerIdx === question.correctAnswer;
            const noAnswer = answerIdx === undefined;
            const pointsMap: Record<string, number> = { easy: 10, medium: 20, hard: 30 };
            const pts = correct ? pointsMap[difficulty ?? 'easy'] : 0;

            return (
              <div
                key={p.id}
                className={`flex items-center gap-3 rounded-xl px-3 py-2.5 border ${
                  noAnswer
                    ? 'bg-white/[0.02] border-white/[0.04]'
                    : correct
                    ? 'bg-[#3d8b4f]/10 border-[#3d8b4f]/20'
                    : 'bg-[#c43d3d]/10 border-[#c43d3d]/20'
                }`}
              >
                <div
                  className="w-7 h-7 rounded-full flex items-center justify-center text-xs shadow-md"
                  style={{ backgroundColor: colorMeta[p.color]?.hex }}
                >
                  {colorMeta[p.color]?.icon}
                </div>
                <span className="text-th-primary text-sm font-medium flex-1">{p.name}</span>
                {noAnswer ? (
                  <span className="text-[10px] text-th-muted font-bold">⏰ No answer</span>
                ) : (
                  <span className={`text-xs font-bold ${correct ? 'text-[#5aab6f]' : 'text-[#e05555]'}`}>
                    {correct ? `+${pts} pts` : '✗'}
                  </span>
                )}
                {p.id === myPlayerId && (
                  <span className="text-[9px] text-th-muted font-bold">YOU</span>
                )}
              </div>
            );
          })}
        </div>

        {/* Next round button */}
        <div className="px-4 pb-4">
          {isMyChooser ? (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onNextRound}
              className="w-full py-2.5 btn-primary rounded-xl text-sm font-bold"
            >
              Next Round →
            </motion.button>
          ) : (
            <p className="text-center text-th-secondary text-xs py-2">
              Waiting for {players.find((p) => p.id === players[0]?.id)?.name} to continue…
            </p>
          )}
        </div>
      </div>
    </motion.div>
  );
}
