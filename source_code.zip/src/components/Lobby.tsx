import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PlayerColor } from '../store/gameStore';
import {
  useRoomStore,
  apiCreateRoom,
  apiJoinRoom,
  emptyGameState,
  RoomGameState,
} from '../store/roomStore';
import { useTheme } from '../store/themeContext';
import cdmxBadge from '../assets/cdmx-badge.png';

const colorOptions: { color: PlayerColor; hex: string; icon: string; label: string }[] = [
  { color: 'car', hex: '#2d6bc4', icon: '🚔', label: 'Police Car' },
  { color: 'moto', hex: '#c43d3d', icon: '🏍️', label: 'Motorcycle' },
  { color: 'bike', hex: '#f5e642', icon: '🚲', label: 'Bicycle' },
  { color: 'horse', hex: '#3d8b4f', icon: '🐴', label: 'Mounted' },
  { color: 'foot', hex: '#c8956c', icon: '🚶', label: 'Foot Patrol' },
];

type Mode = 'menu' | 'create' | 'join';

export default function Lobby({ onBack }: { onBack: () => void }) {
  const { myPlayerId, setRoom, setHost, setError, error } = useRoomStore();
  const { theme, toggleTheme } = useTheme();
  const [mode, setMode] = useState<Mode>('menu');
  const [name, setName] = useState('');
  const [color, setColor] = useState<PlayerColor>('car');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);

  // Prefill join code from ?room= in URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const r = params.get('room');
    if (r) {
      setCode(r.toUpperCase());
      setMode('join');
    }
  }, []);

  const handleCreate = async () => {
    if (!name.trim() || busy) return;
    setBusy(true);
    setError(null);
    try {
      const state: RoomGameState = emptyGameState();
      state.players = [
        {
          id: myPlayerId,
          name: name.trim(),
          color,
          routeIndex: 0,
          currentDistrictId: 1,
          score: 0,
          answeredQuestions: [],
          badge: 'Cadet',
        },
      ];
      const room = await apiCreateRoom(myPlayerId, state);
      setHost(true);
      setRoom(room.code, room.status, room.gameState);
    } catch (e: any) {
      setError(e.message || 'Could not create room');
    } finally {
      setBusy(false);
    }
  };

  const handleJoin = async () => {
    if (!name.trim() || !code.trim() || busy) return;
    setBusy(true);
    setError(null);
    try {
      const room = await apiJoinRoom(code.trim().toUpperCase(), {
        id: myPlayerId,
        name: name.trim(),
        color,
      });
      setHost(false);
      setRoom(room.code, room.status, room.gameState);
    } catch (e: any) {
      setError(e.message || 'Could not join room');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-warm flex items-center justify-center p-4 relative overflow-hidden noise-overlay">
      <button onClick={toggleTheme} className="theme-toggle fixed top-5 right-5 z-50" title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}>
        {theme === 'dark' ? '☀️' : '🌙'}
      </button>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="w-full max-w-lg relative z-10"
      >
        {/* Title */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-2xl overflow-hidden shadow-2xl mx-auto mb-5" style={{ boxShadow: '0 20px 60px rgba(200, 149, 108, 0.3)' }}>
            <img src={cdmxBadge} alt="CDMX Seguridad Pública" className="w-full h-full object-cover" />
          </div>
          <h1 className="font-display text-5xl text-th-primary tracking-wider leading-none mb-2">
            CDMX <span style={{ color: '#c8956c' }}>PATROL</span>
          </h1>
          <p className="text-th-secondary text-sm mt-3">Online Multiplayer — play with friends anywhere</p>
        </div>

        <div className="glass-card rounded-2xl p-6">
          {error && (
            <div className="mb-4 px-4 py-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-300 text-xs">
              {error}
            </div>
          )}

          {mode === 'menu' && (
            <div className="space-y-3">
              <h2 className="text-th-primary font-display text-lg tracking-wider mb-4">CHOOSE HOW TO PLAY</h2>
              <button onClick={() => { setMode('create'); setError(null); }} className="w-full px-5 py-4 btn-primary rounded-xl text-sm font-bold flex items-center justify-center gap-2">
                🏠 Create a Room
              </button>
              <button onClick={() => { setMode('join'); setError(null); }} className="w-full px-5 py-4 rounded-xl text-sm font-bold bg-white/[0.06] hover:bg-white/[0.1] text-th-primary border border-th-medium transition-all flex items-center justify-center gap-2">
                🔑 Join with a Code
              </button>
              <button onClick={onBack} className="w-full px-5 py-3 rounded-xl text-xs text-th-secondary hover:text-th-primary transition-all">
                ← Play locally (same screen)
              </button>

              {/* Game Rules */}
              <div className="mt-5 pt-4 border-t border-white/[0.06]">
                <h3 className="text-th-secondary font-display text-sm tracking-wider mb-3">GAME RULES</h3>
                <div className="space-y-3 text-th-muted text-xs leading-relaxed">
                  <div className="flex gap-2.5">
                    <span className="text-base flex-shrink-0 mt-0.5">🏁</span>
                    <p>All cadets start at <span className="text-th-primary font-medium">Cuauhtémoc</span> and race through the same 16-district patrol route, finishing at <span className="text-th-primary font-medium">Gustavo A. Madero</span>.</p>
                  </div>
                  <div className="flex gap-2.5">
                    <span className="text-base flex-shrink-0 mt-0.5">⏱️</span>
                    <p>Every player answers the <span className="text-th-primary font-medium">same question at the same time</span> — you have <span className="text-th-primary font-medium">30 seconds</span> per question.</p>
                  </div>
                  <div className="flex gap-2.5">
                    <span className="text-base flex-shrink-0 mt-0.5">🎯</span>
                    <p>Only <span className="text-th-primary font-medium">correct answers</span> earn points — wrong answers score nothing.</p>
                  </div>
                  <div className="flex gap-2.5">
                    <span className="text-base flex-shrink-0 mt-0.5">🎚️</span>
                    <p>Each round, one player <span className="text-th-primary font-medium">chooses the difficulty</span> for the borough: <span style={{ color: '#3d8b4f' }}>Easy (10 pts)</span>, <span style={{ color: '#c9a825' }}>Medium (20 pts)</span>, or <span style={{ color: '#c43d3d' }}>Hard (30 pts)</span>.</p>
                  </div>
                  <div className="flex gap-2.5">
                    <span className="text-base flex-shrink-0 mt-0.5">🏆</span>
                    <p>After 16 rounds the cadet with the <span className="text-th-primary font-medium">highest score</span> wins the patrol!</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {(mode === 'create' || mode === 'join') && (
            <div className="space-y-4">
              <h2 className="text-th-primary font-display text-lg tracking-wider">
                {mode === 'create' ? 'CREATE ROOM' : 'JOIN ROOM'}
              </h2>

              {mode === 'join' && (
                <div>
                  <label className="text-th-secondary text-[11px] uppercase tracking-widest font-bold mb-1.5 block">Room Code</label>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value.toUpperCase())}
                    placeholder="ABCDE"
                    maxLength={5}
                    className="w-full bg-white/[0.04] border border-th-medium rounded-xl px-4 py-3 text-th-primary text-center text-2xl font-display tracking-[0.4em] placeholder-th-muted focus:outline-none focus:ring-1 focus:ring-[#c8956c]/50 focus:border-[#c8956c]/50 transition-all uppercase"
                  />
                </div>
              )}

              <div>
                <label className="text-th-secondary text-[11px] uppercase tracking-widest font-bold mb-1.5 block">Your Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your cadet name..."
                  maxLength={12}
                  className="w-full bg-white/[0.04] border border-th-medium rounded-xl px-4 py-3 text-th-primary placeholder-th-muted text-sm focus:outline-none focus:ring-1 focus:ring-[#c8956c]/50 focus:border-[#c8956c]/50 transition-all"
                />
              </div>

              <div>
                <label className="text-th-secondary text-[11px] uppercase tracking-widest font-bold mb-1.5 block">Patrol Type</label>
                <div className="flex gap-2">
                  {colorOptions.map((opt) => (
                    <button
                      key={opt.color}
                      onClick={() => setColor(opt.color)}
                      className={`flex-1 py-2.5 rounded-lg text-xs font-bold transition-all border-2 flex flex-col items-center gap-0.5 ${
                        color === opt.color ? 'border-white/80 scale-105' : 'border-transparent hover:border-white/30'
                      }`}
                      style={{ backgroundColor: opt.hex }}
                    >
                      <span className="text-lg leading-none">{opt.icon}</span>
                      <span className="text-th-primary text-[10px] drop-shadow-sm">{opt.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 pt-1">
                <button onClick={() => { setMode('menu'); setError(null); }} className="px-4 py-3 rounded-xl text-sm text-th-secondary hover:text-th-primary hover:bg-white/[0.04] transition-all">
                  ← Back
                </button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={mode === 'create' ? handleCreate : handleJoin}
                  disabled={busy || !name.trim() || (mode === 'join' && code.trim().length < 5)}
                  className="flex-1 px-5 py-3 btn-primary disabled:bg-white/10 disabled:text-white/20 disabled:cursor-not-allowed rounded-xl text-sm font-bold transition-all"
                >
                  {busy ? 'Please wait…' : mode === 'create' ? 'Create Room' : 'Join Room'}
                </motion.button>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
