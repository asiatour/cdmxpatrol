import { districts, patrolRoute, TriviaQuestion } from '../data/districts';
import { RoomGameState, RoomAction } from './roomStore';

// Question resolution reuses the same override/deleted refs as local mode
import type { CustomQuestionStore } from './useCustomQuestions';

let customRef: CustomQuestionStore[] = [];
let editedRef: Record<string, { districtId: number; question: TriviaQuestion }> = {};
let deletedRef: string[] = [];

export function setEngineQuestionRefs(
  custom: CustomQuestionStore[],
  edited: Record<string, { districtId: number; question: TriviaQuestion }>,
  deleted: string[],
) {
  customRef = custom;
  editedRef = edited;
  deletedRef = deleted;
}

function pickQuestion(districtId: number, difficulty: 'easy' | 'medium' | 'hard'): TriviaQuestion | null {
  const district = districts.find((d) => d.id === districtId);
  if (!district) return null;

  const effectiveBuiltIn = district.trivia
    .filter((q) => !deletedRef.includes(q.id))
    .map((q) => (editedRef[q.id] ? editedRef[q.id].question : q));

  const matching = [
    ...effectiveBuiltIn.filter((q) => q.difficulty === difficulty),
    ...customRef
      .filter((cq) => cq.districtId === districtId && cq.question.difficulty === difficulty)
      .map((cq) => cq.question),
  ];

  const pool = matching.length > 0
    ? matching
    : [
        ...effectiveBuiltIn,
        ...customRef.filter((cq) => cq.districtId === districtId).map((cq) => cq.question),
      ];

  if (pool.length === 0) return null;
  return pool[Math.floor(Math.random() * pool.length)];
}

const ANSWER_TIME_MS = 30_000; // 30 seconds

// Apply a single action to the state (host-side authoritative reducer)
export function applyAction(state: RoomGameState, action: RoomAction): RoomGameState {
  const s: RoomGameState = JSON.parse(JSON.stringify(state));

  // If the timer has expired and we're in trivia phase, auto-resolve first
  if (s.phase === 'trivia' && s.timerEnd && Date.now() >= s.timerEnd) {
    return resolveRound(s);
  }

  switch (action.type) {
    case 'chooseDifficulty': {
      // Only the difficulty chooser may act, and only in 'playing' phase
      if (s.phase !== 'playing') return state;
      if (action.playerId !== s.difficultyChooserId) return state;

      const difficulty = (action.payload?.difficulty ?? 'easy') as 'easy' | 'medium' | 'hard';
      const q = pickQuestion(s.currentDistrictId, difficulty);
      if (!q) return state;

      s.phase = 'trivia';
      s.currentQuestion = q;
      s.currentDifficulty = difficulty;
      s.answers = {};
      s.timerEnd = Date.now() + ANSWER_TIME_MS;
      s.showResult = false;

      const chooser = s.players.find((p) => p.id === action.playerId);
      const district = districts.find((d) => d.id === s.currentDistrictId);
      s.gameLog.push(
        `🎯 ${chooser?.name ?? 'Player'} chose ${difficulty.toUpperCase()} for ${district?.name ?? 'Borough #' + s.currentDistrictId}`,
      );
      return s;
    }

    case 'submitAnswer': {
      // Any player can answer during trivia phase, before timer expires
      if (s.phase !== 'trivia') return state;
      if (!s.currentQuestion) return state;
      if (s.timerEnd && Date.now() >= s.timerEnd) {
        // Timer expired — resolve
        return resolveRound(s);
      }
      // Don't allow double-answering
      if (action.playerId in s.answers) return state;

      const answerIndex = action.payload?.answerIndex as number;
      if (typeof answerIndex !== 'number') return state;

      s.answers[action.playerId] = answerIndex;

      const player = s.players.find((p) => p.id === action.playerId);
      const correct = answerIndex === s.currentQuestion.correctAnswer;
      const pointsMap: Record<string, number> = { easy: 10, medium: 20, hard: 30 };
      const points = correct ? pointsMap[s.currentQuestion.difficulty] : 0;

      if (player) {
        const newScore = player.score + points;
        let newBadge = player.badge;
        if (newScore >= 400) newBadge = 'Comisario';
        else if (newScore >= 300) newBadge = 'Inspector';
        else if (newScore >= 200) newBadge = 'Oficial';
        else if (newScore >= 100) newBadge = 'Policia';
        else newBadge = 'Cadete';
        player.score = newScore;
        player.badge = newBadge;
        player.answeredQuestions = [...player.answeredQuestions, s.currentQuestion.id];

        s.gameLog.push(
          correct
            ? `✅ ${player.name} answered correctly! +${points} pts`
            : `❌ ${player.name} answered incorrectly.`,
        );
      }

      // If all players have answered, resolve immediately
      const allAnswered = s.players.every((p) => p.id in s.answers);
      if (allAnswered) {
        return resolveRound(s);
      }

      return s;
    }

    case 'nextRound': {
      // Only valid during roundResult phase
      if (s.phase !== 'roundResult') return state;

      return advanceRound(s);
    }

    default:
      return state;
  }
}

/** Award points for correct answers and show results */
function resolveRound(s: RoomGameState): RoomGameState {
  if (s.phase !== 'trivia' || !s.currentQuestion) return s;

  // Award points to players who answered correctly (if not already awarded)
  const pointsMap: Record<string, number> = { easy: 10, medium: 20, hard: 30 };
  const points = pointsMap[s.currentQuestion.difficulty];

  for (const player of s.players) {
    if (!(player.id in s.answers)) {
      // Player didn't answer in time
      s.gameLog.push(`⏰ ${player.name} ran out of time!`);
      continue;
    }
    // Points already awarded during submitAnswer, so nothing more to do here
  }

  s.phase = 'roundResult';
  s.showResult = true;
  s.timerEnd = null;

  const district = districts.find((d) => d.id === s.currentDistrictId);
  s.gameLog.push(`📋 Round results for ${district?.name ?? 'Borough'}:`);
  for (const player of s.players) {
    const answerIdx = s.answers[player.id];
    if (answerIdx === undefined) {
      s.gameLog.push(`  ⏰ ${player.name}: no answer`);
    } else {
      const correct = answerIdx === s.currentQuestion.correctAnswer;
      s.gameLog.push(`  ${correct ? '✅' : '❌'} ${player.name}: ${correct ? 'Correct' : 'Incorrect'}`);
    }
  }

  return s;
}

/** Advance to the next round (next borough) */
function advanceRound(s: RoomGameState): RoomGameState {
  const nextRound = s.roundNumber + 1;

  // Check if game is over (all 16 rounds done)
  if (nextRound >= patrolRoute.length) {
    s.phase = 'gameover';
    s.currentQuestion = null;
    s.showResult = false;
    s.gameLog.push('🏆 All rounds complete! Final scores:');
    // Sort players by score for final ranking
    const sorted = [...s.players].sort((a, b) => b.score - a.score);
    sorted.forEach((p, i) => {
      s.gameLog.push(`  ${i + 1}. ${p.name} — ${p.score} pts (${p.badge})`);
    });
    return s;
  }

  // Advance all players to next district
  s.players = s.players.map((p) => ({
    ...p,
    routeIndex: p.routeIndex + 1,
    currentDistrictId: patrolRoute[p.routeIndex + 1],
  }));

  s.roundNumber = nextRound;
  s.currentDistrictId = patrolRoute[nextRound];

  // Rotate difficulty chooser (next player in line)
  const currentChooserIdx = s.players.findIndex((p) => p.id === s.difficultyChooserId);
  const nextChooserIdx = (currentChooserIdx + 1) % s.players.length;
  s.difficultyChooserId = s.players[nextChooserIdx].id;

  // Reset for next round
  s.phase = 'playing';
  s.currentQuestion = null;
  s.currentDifficulty = null;
  s.answers = {};
  s.timerEnd = null;
  s.showResult = false;

  const district = districts.find((d) => d.id === s.currentDistrictId);
  const chooser = s.players[nextChooserIdx];
  s.gameLog.push(
    ` round ${nextRound + 1}/16 — ${district?.name ?? 'Borough #' + s.currentDistrictId} — ${chooser.name} chooses difficulty`,
  );

  return s;
}

// Host drains the queue: apply all unprocessed actions in order.
// Returns { state, changed }.
export function drainQueue(state: RoomGameState): { state: RoomGameState; changed: boolean } {
  if (!state.actionQueue || state.actionQueue.length === 0) {
    // Even with no actions, check if timer expired
    if (state.phase === 'trivia' && state.timerEnd && Date.now() >= state.timerEnd) {
      const resolved = resolveRound(JSON.parse(JSON.stringify(state)));
      return { state: resolved, changed: true };
    }
    return { state, changed: false };
  }

  let s = state;
  let changed = false;
  const processed = new Set(s.processedActions || []);

  for (const action of s.actionQueue) {
    if (processed.has(action.id)) continue;
    const next = applyAction(s, action);
    if (next !== s) {
      s = next;
      changed = true;
    }
    processed.add(action.id);
  }

  // Check if timer expired after processing actions
  if (s.phase === 'trivia' && s.timerEnd && Date.now() >= s.timerEnd) {
    const resolved = resolveRound(s);
    if (resolved !== s) {
      s = resolved;
      changed = true;
    }
  }

  if (changed || (s.actionQueue && s.actionQueue.length > 0)) {
    s = JSON.parse(JSON.stringify(s));
    s.actionQueue = [];
    s.processedActions = Array.from(processed).slice(-50);
    s.updatedAt = Date.now();
    changed = true;
  }

  return { state: s, changed };
}

/** Create the initial game state when the host starts the game */
export function startGameState(state: RoomGameState): RoomGameState {
  const s: RoomGameState = JSON.parse(JSON.stringify(state));
  s.phase = 'playing';
  s.roundNumber = 0;
  s.currentDistrictId = patrolRoute[0];
  s.difficultyChooserId = s.players[0]?.id ?? null;
  s.currentQuestion = null;
  s.currentDifficulty = null;
  s.answers = {};
  s.timerEnd = null;
  s.showResult = false;

  // Initialize all players at the first district
  s.players = s.players.map((p) => ({
    ...p,
    routeIndex: 0,
    currentDistrictId: patrolRoute[0],
    score: 0,
    answeredQuestions: [],
    badge: 'Cadete',
  }));

  s.gameLog = [
    '🚨 Mission briefing: All cadets patrol together through 16 districts!',
    `Round 1/16 — ${districts.find((d) => d.id === patrolRoute[0])?.name}`,
    `${s.players[0]?.name ?? 'Player 1'} chooses the difficulty.`,
  ];
  s.updatedAt = Date.now();
  return s;
}
