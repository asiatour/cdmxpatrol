import { create } from 'zustand';
import { PlayerColor } from './gameStore';
import { client } from '../api/client';

export { API_BASE } from '../api/client';

export interface RoomPlayer {
  id: string;
  name: string;
  color: PlayerColor;
  routeIndex: number;
  currentDistrictId: number;
  score: number;
  answeredQuestions: string[];
  badge: string;
}

// A remote action a guest wants the host to apply.
export interface RoomAction {
  id: string;            // unique action id (dedupe)
  playerId: string;      // who issued it
  type: 'chooseDifficulty' | 'submitAnswer' | 'nextRound';
  payload?: any;         // e.g. { difficulty } or { answerIndex }
  ts: number;
}

// The full authoritative game state stored in rooms.game_state (host writes it)
export interface RoomGameState {
  phase: 'lobby' | 'playing' | 'trivia' | 'roundResult' | 'gameover';
  players: RoomPlayer[];
  roundNumber: number;                        // 0-15 (current round/borough)
  currentDistrictId: number;                  // shared district for all players
  difficultyChooserId: string | null;         // which player picks difficulty this round
  currentQuestion: any | null;
  currentDifficulty: 'easy' | 'medium' | 'hard' | null;
  answers: Record<string, number>;            // playerId -> answerIndex
  timerEnd: number | null;                    // timestamp when 10s timer expires
  showResult: boolean;                        // whether results are being shown
  gameLog: string[];
  actionQueue: RoomAction[];                  // pending guest actions for host to consume
  processedActions: string[];                 // ids the host already applied
  updatedAt: number;
}

export type RoomStatus = 'waiting' | 'playing' | 'abandoned';

interface RoomStoreState {
  // identity
  myPlayerId: string;
  isHost: boolean;
  roomCode: string | null;
  roomStatus: RoomStatus;
  gameState: RoomGameState | null;
  error: string | null;
  connecting: boolean;

  setMyPlayerId: (id: string) => void;
  setHost: (v: boolean) => void;
  setRoom: (code: string, status: RoomStatus, gameState: RoomGameState | null) => void;
  setError: (e: string | null) => void;
  setConnecting: (v: boolean) => void;
  leaveRoom: () => void;
}

// Stable per-browser player id
function loadPlayerId(): string {
  const KEY = 'cdmx-patrol-player-id';
  let id = localStorage.getItem(KEY);
  if (!id) {
    id = 'p-' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
    localStorage.setItem(KEY, id);
  }
  return id;
}

export const useRoomStore = create<RoomStoreState>((set) => ({
  myPlayerId: loadPlayerId(),
  isHost: false,
  roomCode: null,
  roomStatus: 'waiting',
  gameState: null,
  error: null,
  connecting: false,

  setMyPlayerId: (id) => set({ myPlayerId: id }),
  setHost: (v) => set({ isHost: v }),
  setRoom: (code, status, gameState) => set({ roomCode: code, roomStatus: status, gameState }),
  setError: (e) => set({ error: e }),
  setConnecting: (v) => set({ connecting: v }),
  leaveRoom: () => set({ roomCode: null, isHost: false, gameState: null, roomStatus: 'waiting', error: null }),
}));

// ─── API helpers ───

export function emptyGameState(): RoomGameState {
  return {
    phase: 'lobby',
    players: [],
    roundNumber: 0,
    currentDistrictId: 12,  // Cuauhtémoc (patrolRoute[0])
    difficultyChooserId: null,
    currentQuestion: null,
    currentDifficulty: null,
    answers: {},
    timerEnd: null,
    showResult: false,
    gameLog: [],
    actionQueue: [],
    processedActions: [],
    updatedAt: Date.now(),
  };
}

export async function apiCreateRoom(hostPlayerId: string, gameState: RoomGameState) {
  const res = await client.api.fetch('/api/public/rooms', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ host_player_id: hostPlayerId, game_state: gameState }),
  });
  if (!res.ok) throw new Error('Failed to create room');
  const json = await res.json();
  return json.data as { code: string; status: RoomStatus; gameState: RoomGameState };
}

export async function apiGetRoom(code: string) {
  const res = await client.api.fetch(`/api/public/rooms/${encodeURIComponent(code)}`);
  if (res.status === 404) return null;
  if (!res.ok) throw new Error('Failed to load room');
  const json = await res.json();
  return json.data as { code: string; status: RoomStatus; gameState: RoomGameState };
}

export async function apiJoinRoom(code: string, player: { id: string; name: string; color: PlayerColor }) {
  const res = await client.api.fetch(`/api/public/rooms/${encodeURIComponent(code)}/join`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ player }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(json.error || 'Failed to join room');
  }
  return json.data as { code: string; status: RoomStatus; gameState: RoomGameState };
}

export async function apiUpdateRoom(code: string, opts: { gameState?: RoomGameState; status?: RoomStatus }) {
  const body: any = {};
  if (opts.gameState !== undefined) body.game_state = opts.gameState;
  if (opts.status !== undefined) body.status = opts.status;
  const res = await client.api.fetch(`/api/public/rooms/${encodeURIComponent(code)}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error('Failed to update room');
  const json = await res.json();
  return json.data as { code: string; status: RoomStatus; gameState: RoomGameState };
}
