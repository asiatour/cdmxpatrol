import { create } from 'zustand';
import { TriviaQuestion } from '../data/districts';
import { client } from '../api/client';

const STORAGE_KEY = 'cdmx-patrol-custom-questions';
const OVERRIDES_KEY = 'cdmx-patrol-edited-questions';
const DELETED_KEY = 'cdmx-patrol-deleted-questions';

// All backend routes (reads and writes) live under /api/public/* —
// no login is required anywhere. The teacher sign-in gate was removed.

export interface CustomQuestionStore {
  districtId: number;
  question: TriviaQuestion;
}

// ─── localStorage helpers ───

function loadCustomQuestions(): CustomQuestionStore[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function loadEditedQuestions(): Record<string, { districtId: number; question: TriviaQuestion }> {
  try {
    const raw = localStorage.getItem(OVERRIDES_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function loadDeletedIds(): string[] {
  try {
    const raw = localStorage.getItem(DELETED_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveCustomQuestions(questions: CustomQuestionStore[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(questions));
}

function saveEditedQuestions(overrides: Record<string, { districtId: number; question: TriviaQuestion }>) {
  localStorage.setItem(OVERRIDES_KEY, JSON.stringify(overrides));
}

function saveDeletedIds(ids: string[]) {
  localStorage.setItem(DELETED_KEY, JSON.stringify(ids));
}

// ─── Backend API helpers ───

async function fetchBackendQuestions(): Promise<CustomQuestionStore[]> {
  try {
    const res = await client.api.fetch('/api/public/questions');
    if (!res.ok) return [];
    const json = await res.json();
    if (!json.data) return [];
    return json.data.map((row: any) => ({
      districtId: row.district_id ?? row.districtId,
      question: {
        id: row.question_id ?? row.questionId,
        question: row.question_text ?? row.questionText,
        options: [row.option_0 ?? row.option0, row.option_1 ?? row.option1, row.option_2 ?? row.option2, row.option_3 ?? row.option3],
        correctAnswer: row.correct_answer ?? row.correctAnswer,
        difficulty: row.difficulty,
        category: row.category,
      } as TriviaQuestion,
    }));
  } catch {
    return [];
  }
}

async function fetchBackendOverrides(): Promise<Record<string, { districtId: number; question: TriviaQuestion }>> {
  try {
    const res = await client.api.fetch('/api/public/question-overrides');
    if (!res.ok) return {};
    const json = await res.json();
    if (!json.data) return {};
    const result: Record<string, { districtId: number; question: TriviaQuestion }> = {};
    for (const row of json.data) {
      const qId = row.question_id ?? row.questionId;
      result[qId] = {
        districtId: row.district_id ?? row.districtId,
        question: {
          id: qId,
          question: row.question_text ?? row.questionText,
          options: [row.option_0 ?? row.option0, row.option_1 ?? row.option1, row.option_2 ?? row.option2, row.option_3 ?? row.option3],
          correctAnswer: row.correct_answer ?? row.correctAnswer,
          difficulty: row.difficulty,
          category: row.category,
        } as TriviaQuestion,
      };
    }
    return result;
  } catch {
    return {};
  }
}

async function fetchBackendDeletions(): Promise<string[]> {
  try {
    const res = await client.api.fetch('/api/public/question-deletions');
    if (!res.ok) return [];
    const json = await res.json();
    if (!json.data) return [];
    return json.data.map((row: any) => row.question_id ?? row.questionId);
  } catch {
    return [];
  }
}

async function createBackendQuestion(districtId: number, question: TriviaQuestion): Promise<boolean> {
  try {
    const res = await client.api.fetch('/api/public/questions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        district_id: districtId,
        question_id: question.id,
        question_text: question.question,
        option_0: question.options[0],
        option_1: question.options[1],
        option_2: question.options[2],
        option_3: question.options[3],
        correct_answer: question.correctAnswer,
        difficulty: question.difficulty,
        category: question.category,
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function updateBackendQuestion(questionId: string, districtId: number, question: TriviaQuestion): Promise<boolean> {
  try {
    const res = await client.api.fetch(`/api/public/questions/${encodeURIComponent(questionId)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        question_text: question.question,
        option_0: question.options[0],
        option_1: question.options[1],
        option_2: question.options[2],
        option_3: question.options[3],
        correct_answer: question.correctAnswer,
        difficulty: question.difficulty,
        category: question.category,
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function deleteBackendQuestion(questionId: string): Promise<boolean> {
  try {
    const res = await client.api.fetch(`/api/public/questions/${encodeURIComponent(questionId)}`, {
      method: 'DELETE',
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function saveBackendOverride(questionId: string, districtId: number, question: TriviaQuestion): Promise<boolean> {
  try {
    const res = await client.api.fetch(`/api/public/question-overrides/${encodeURIComponent(questionId)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        district_id: districtId,
        question_text: question.question,
        option_0: question.options[0],
        option_1: question.options[1],
        option_2: question.options[2],
        option_3: question.options[3],
        correct_answer: question.correctAnswer,
        difficulty: question.difficulty,
        category: question.category,
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function deleteBackendOverride(questionId: string): Promise<boolean> {
  try {
    const res = await client.api.fetch(`/api/public/question-overrides/${encodeURIComponent(questionId)}`, {
      method: 'DELETE',
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function saveBackendDeletion(questionId: string): Promise<boolean> {
  try {
    const res = await client.api.fetch('/api/public/question-deletions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question_id: questionId }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function deleteBackendDeletion(questionId: string): Promise<boolean> {
  try {
    const res = await client.api.fetch(`/api/public/question-deletions/${encodeURIComponent(questionId)}`, {
      method: 'DELETE',
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function fetchBackendDeletedCustomQuestions(): Promise<CustomQuestionStore[]> {
  try {
    const res = await client.api.fetch('/api/public/deleted-custom-questions');
    if (!res.ok) return [];
    const json = await res.json();
    if (!json.data) return [];
    return json.data.map((row: any) => ({
      districtId: row.district_id ?? row.districtId,
      question: {
        id: row.question_id ?? row.questionId,
        question: row.question_text ?? row.questionText,
        options: [row.option_0 ?? row.option0, row.option_1 ?? row.option1, row.option_2 ?? row.option2, row.option_3 ?? row.option3],
        correctAnswer: row.correct_answer ?? row.correctAnswer,
        difficulty: row.difficulty,
        category: row.category,
      } as TriviaQuestion,
    }));
  } catch {
    return [];
  }
}

async function saveBackendDeletedCustomQuestion(districtId: number, question: TriviaQuestion): Promise<boolean> {
  try {
    const res = await client.api.fetch('/api/public/deleted-custom-questions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        district_id: districtId,
        question_id: question.id,
        question_text: question.question,
        option_0: question.options[0],
        option_1: question.options[1],
        option_2: question.options[2],
        option_3: question.options[3],
        correct_answer: question.correctAnswer,
        difficulty: question.difficulty,
        category: question.category,
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function deleteBackendDeletedCustomQuestion(questionId: string): Promise<boolean> {
  try {
    const res = await client.api.fetch(`/api/public/deleted-custom-questions/${encodeURIComponent(questionId)}`, {
      method: 'DELETE',
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ─── Zustand store ───

interface CustomQuestionsState {
  customQuestions: CustomQuestionStore[];
  editedQuestions: Record<string, { districtId: number; question: TriviaQuestion }>;
  deletedIds: string[];
  deletedCustomQuestions: CustomQuestionStore[];
  synced: boolean;

  addQuestion: (districtId: number, question: TriviaQuestion) => void;
  updateQuestion: (questionId: string, districtId: number, updated: TriviaQuestion) => void;
  deleteQuestion: (questionId: string) => void;
  restoreDeletedQuestion: (questionId: string) => void;
  saveBuiltInOverride: (questionId: string, districtId: number, updated: TriviaQuestion) => void;
  deleteBuiltInQuestion: (questionId: string) => void;
  restoreBuiltInQuestion: (questionId: string) => void;
  revertBuiltInOverride: (questionId: string) => void;
  getQuestionsForDistrict: (districtId: number) => TriviaQuestion[];
  clearAll: () => void;
  mergeBackendQuestions: () => void;
}

export const useCustomQuestions = create<CustomQuestionsState>((set, get) => ({
  customQuestions: loadCustomQuestions(),
  editedQuestions: loadEditedQuestions(),
  deletedIds: loadDeletedIds(),
  deletedCustomQuestions: [],
  synced: false,

  addQuestion: (districtId, question) => {
    set((state) => {
      const next = [...state.customQuestions, { districtId, question }];
      saveCustomQuestions(next);
      return { customQuestions: next };
    });
    createBackendQuestion(districtId, question);
  },

  updateQuestion: (questionId, districtId, updated) => {
    set((state) => {
      const next = state.customQuestions.map((cq) =>
        cq.question.id === questionId
          ? { districtId, question: updated }
          : cq
      );
      saveCustomQuestions(next);
      return { customQuestions: next };
    });
    updateBackendQuestion(questionId, districtId, updated);
  },

  deleteQuestion: (questionId) => {
    set((state) => {
      const removed = state.customQuestions.find((cq) => cq.question.id === questionId);
      if (!removed) return state;
      const next = state.customQuestions.filter((cq) => cq.question.id !== questionId);
      const nextDeleted = [...state.deletedCustomQuestions, removed];
      saveCustomQuestions(next);
      return { customQuestions: next, deletedCustomQuestions: nextDeleted };
    });
    // Find the question data to send to backend
    const state = get();
    const removed = state.deletedCustomQuestions.find((cq) => cq.question.id === questionId);
    if (removed) {
      saveBackendDeletedCustomQuestion(removed.districtId, removed.question);
    }
    deleteBackendQuestion(questionId);
  },

  restoreDeletedQuestion: (questionId) => {
    set((state) => {
      const restored = state.deletedCustomQuestions.find((cq) => cq.question.id === questionId);
      if (!restored) return state;
      const nextDeleted = state.deletedCustomQuestions.filter((cq) => cq.question.id !== questionId);
      const nextCustom = [...state.customQuestions, restored];
      saveCustomQuestions(nextCustom);
      return { customQuestions: nextCustom, deletedCustomQuestions: nextDeleted };
    });
    // Re-create in the main questions table
    const state = get();
    const restored = state.customQuestions.find((cq) => cq.question.id === questionId);
    if (restored) {
      createBackendQuestion(restored.districtId, restored.question);
    }
    deleteBackendDeletedCustomQuestion(questionId);
  },

  saveBuiltInOverride: (questionId, districtId, updated) => {
    set((state) => {
      const next = { ...state.editedQuestions, [questionId]: { districtId, question: updated } };
      saveEditedQuestions(next);
      return { editedQuestions: next };
    });
    saveBackendOverride(questionId, districtId, updated);
  },

  deleteBuiltInQuestion: (questionId) => {
    set((state) => {
      if (state.deletedIds.includes(questionId)) return state;
      const next = [...state.deletedIds, questionId];
      saveDeletedIds(next);
      return { deletedIds: next };
    });
    saveBackendDeletion(questionId);
  },

  restoreBuiltInQuestion: (questionId) => {
    set((state) => {
      const next = state.deletedIds.filter((id) => id !== questionId);
      saveDeletedIds(next);
      return { deletedIds: next };
    });
    deleteBackendDeletion(questionId);
  },

  revertBuiltInOverride: (questionId) => {
    set((state) => {
      const next = { ...state.editedQuestions };
      delete next[questionId];
      saveEditedQuestions(next);
      return { editedQuestions: next };
    });
    deleteBackendOverride(questionId);
  },

  getQuestionsForDistrict: (districtId) => {
    return get().customQuestions
      .filter((cq) => cq.districtId === districtId)
      .map((cq) => cq.question);
  },

  clearAll: () => {
    set(() => {
      saveCustomQuestions([]);
      return { customQuestions: [] };
    });
  },

  mergeBackendQuestions: () => {
    Promise.all([
      fetchBackendQuestions(),
      fetchBackendOverrides(),
      fetchBackendDeletions(),
      fetchBackendDeletedCustomQuestions(),
    ]).then(([backendQuestions, backendOverrides, backendDeletions, backendDeletedCustom]) => {
      set((state) => {
        // Merge custom questions: backend is source of truth, keep local-only ones
        let mergedCustom = state.customQuestions;
        if (backendQuestions.length > 0) {
          const localIds = new Set(state.customQuestions.map((cq) => cq.question.id));
          const merged = [...backendQuestions];
          for (const local of state.customQuestions) {
            if (!localIds.has(local.question.id)) {
              merged.push(local);
            }
          }
          mergedCustom = merged;
        }

        // Merge overrides: backend is source of truth, keep local-only ones
        const mergedOverrides = { ...backendOverrides };
        for (const [qId, localOverride] of Object.entries(state.editedQuestions)) {
          if (!mergedOverrides[qId]) {
            mergedOverrides[qId] = localOverride;
          }
        }

        // Merge deletions: backend is source of truth, keep local-only ones
        const mergedDeletionsSet = new Set(backendDeletions);
        for (const localId of state.deletedIds) {
          mergedDeletionsSet.add(localId);
        }
        const mergedDeletions = [...mergedDeletionsSet];

        // Merge deleted custom questions: backend is source of truth, keep local-only
        const mergedDeletedCustom = [...backendDeletedCustom];
        const backendIds = new Set(backendDeletedCustom.map((cq) => cq.question.id));
        for (const local of state.deletedCustomQuestions) {
          if (!backendIds.has(local.question.id)) {
            mergedDeletedCustom.push(local);
          }
        }

        saveCustomQuestions(mergedCustom);
        saveEditedQuestions(mergedOverrides);
        saveDeletedIds(mergedDeletions);

        return {
          customQuestions: mergedCustom,
          editedQuestions: mergedOverrides,
          deletedIds: mergedDeletions,
          deletedCustomQuestions: mergedDeletedCustom,
          synced: true,
        };
      });
    });
  },
}));
