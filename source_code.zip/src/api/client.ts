import { createEdgeSpark } from '@edgespark/client';
import '@edgespark/client/styles.css';

// Staging worker URL (Youbase/EdgeSpark backend)
export const API_BASE = 'https://staging--6s8fja7r21gpiv773y9u.youbase.cloud';

// Single EdgeSpark client for the whole app — API calls go through
// client.api.fetch. No sign-in is required anywhere (teacher login removed).
export const client = createEdgeSpark({ baseUrl: API_BASE });
